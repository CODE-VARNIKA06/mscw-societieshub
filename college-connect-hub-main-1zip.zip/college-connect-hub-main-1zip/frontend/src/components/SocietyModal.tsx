import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, ExternalLink, Instagram, Linkedin, Mail, Users, Calendar, Clock, MapPin, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Society, getCategoryColor, getStatusBadge, getStatusText, categoryLabels } from '@/data/societies';
import { useFollowing } from '@/hooks/useFollowing';
import { RegistrationModal } from './RegistrationModal';

interface SocietyModalProps {
  society: Society | null;
  isOpen: boolean;
  onClose: () => void;
}

export const SocietyModal = ({ society, isOpen, onClose }: SocietyModalProps) => {
  const { isFollowing, toggleFollow } = useFollowing();
  const [showRegistration, setShowRegistration] = useState(false);
  
  if (!society) return null;
  
  const following = isFollowing(society.id);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-background/80 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative w-full max-w-2xl max-h-[90vh] overflow-hidden glass-card rounded-3xl"
            style={{
              boxShadow: `0 0 80px hsl(${society.colorAccent} / 0.2)`
            }}
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-background/50 backdrop-blur-sm flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div 
              className="relative h-40 overflow-hidden"
              style={{
                background: `linear-gradient(135deg, hsl(${society.colorAccent} / 0.4) 0%, hsl(${society.colorAccent} / 0.1) 100%)`
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
              
              {/* Society Logo/Initial */}
              <div 
                className="absolute bottom-0 left-6 translate-y-1/2 w-20 h-20 rounded-2xl flex items-center justify-center text-3xl font-display font-bold border-4 border-card shadow-xl"
                style={{
                  background: `linear-gradient(135deg, hsl(${society.colorAccent}), hsl(${society.colorAccent} / 0.7))`,
                  color: 'white'
                }}
              >
                {society.name.charAt(0)}
              </div>

              {/* Follow Button */}
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => toggleFollow(society.id)}
                className={`absolute bottom-4 right-6 px-5 py-2.5 rounded-full flex items-center gap-2 font-medium transition-all ${
                  following 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-background/50 backdrop-blur-sm text-foreground hover:bg-background/70'
                }`}
              >
                <Heart className={`w-4 h-4 ${following ? 'fill-current' : ''}`} />
                {following ? 'Following' : 'Follow'}
              </motion.button>
            </div>

            {/* Content */}
            <div className="p-6 pt-14 overflow-y-auto max-h-[calc(90vh-10rem)]">
              {/* Title and Badges */}
              <div className="mb-6">
                <h2 className="font-display text-2xl font-bold text-foreground mb-2">
                  {society.name}
                </h2>
                <p className="text-muted-foreground mb-4">{society.department}</p>
                
                <div className="flex flex-wrap gap-2">
                  <span className={`px-3 py-1.5 rounded-full text-sm font-medium ${getCategoryColor(society.category)}`}>
                    {categoryLabels[society.category]}
                  </span>
                  <span className={`px-3 py-1.5 rounded-full text-sm font-medium ${getStatusBadge(society.registrationStatus)}`}>
                    {getStatusText(society.registrationStatus)}
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h3 className="font-semibold text-foreground mb-2">About</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {society.description}
                </p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="glass-card p-4 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Users className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">{society.memberCount}+</p>
                      <p className="text-sm text-muted-foreground">Members</p>
                    </div>
                  </div>
                </div>

                {society.fest && (
                  <div className="glass-card p-4 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                        <Calendar className="w-5 h-5 text-accent" />
                      </div>
                      <div>
                        <p className="text-lg font-bold text-foreground">{society.fest.name}</p>
                        <p className="text-sm text-muted-foreground">{society.fest.date}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Registration Section */}
              {society.registrationStatus === 'open' && (
                <div className="mb-6 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-emerald-400">Registrations Open!</h4>
                      <p className="text-sm text-muted-foreground">Apply now to join {society.name}</p>
                    </div>
                    <Button
                      className="bg-emerald-500 hover:bg-emerald-600 text-white"
                      onClick={() => setShowRegistration(true)}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Register Now
                    </Button>
                  </div>
                </div>
              )}

              {society.registrationStatus === 'soon' && society.registrationDate && (
                <div className="mb-6 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-amber-400" />
                    <div>
                      <h4 className="font-semibold text-amber-400">Registrations Opening Soon</h4>
                      <p className="text-sm text-muted-foreground">Expected: {society.registrationDate}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Leadership */}
              <div className="mb-6">
                <h3 className="font-semibold text-foreground mb-3">Leadership</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{society.contact.president}</p>
                      <p className="text-xs text-muted-foreground">President</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                    <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                      <User className="w-5 h-5 text-accent" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{society.contact.prLead}</p>
                      <p className="text-xs text-muted-foreground">PR Lead</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Links */}
              <div>
                <h3 className="font-semibold text-foreground mb-3">Connect</h3>
                <div className="flex flex-wrap gap-3">
                  {society.contact.instagram && (
                    <a
                      href={society.contact.instagram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
                    >
                      <Instagram className="w-4 h-4" />
                      Instagram
                    </a>
                  )}
                  {society.contact.linkedin && (
                    <a
                      href={society.contact.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
                    >
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </a>
                  )}
                  {society.contact.email && (
                    <a
                      href={`mailto:${society.contact.email}`}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
                    >
                      <Mail className="w-4 h-4" />
                      Email
                    </a>
                  )}
                </div>
              </div>
            </div>
          </motion.div>

          <RegistrationModal
            societyName={society.name}
            isOpen={showRegistration}
            onClose={() => setShowRegistration(false)}
          />
        </div>
      )}
    </AnimatePresence>
  );
};
