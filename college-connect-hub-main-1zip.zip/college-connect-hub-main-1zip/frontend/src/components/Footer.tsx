import { motion } from 'framer-motion';
import { Heart, Instagram, Linkedin, Twitter, Mail, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative pt-20 pb-8 border-t border-border/50">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none" />

      <div className="container mx-auto px-4 relative">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <span className="text-lg font-bold text-primary-foreground">M</span>
              </div>
              <div>
                <h3 className="font-display font-bold text-lg">MSCW Hub</h3>
                <p className="text-xs text-muted-foreground">Find Your Tribe</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Your one-stop destination for all college societies, events, and opportunities.
            </p>
            <div className="flex items-center gap-2">
              <a href="#" className="w-9 h-9 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-all">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-all">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Explore</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#societies" className="hover:text-foreground transition-colors">All Societies</a></li>
              <li><a href="#calendar" className="hover:text-foreground transition-colors">Event Calendar</a></li>
              <li><a href="#following" className="hover:text-foreground transition-colors">My Dashboard</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Registration Portal</a></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Categories</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground transition-colors">Technology</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Cultural</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Sports</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Arts & Design</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Media</a></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Stay Updated</h4>
            <p className="text-sm text-muted-foreground mb-4">
              Get notified about new societies and events.
            </p>
            <div className="flex gap-2">
              <Input 
                placeholder="Enter your email" 
                className="bg-card/50 border-border/50"
              />
              <Button className="bg-primary hover:bg-primary/90 shrink-0">
                <Mail className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-border/50 gap-4">
          <p className="text-sm text-muted-foreground">
            © 2026 MSCW Societies Hub. Made with{' '}
            <Heart className="w-4 h-4 inline text-destructive fill-destructive" />{' '}
            for students.
          </p>
          
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-foreground transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-foreground transition-colors">Contact</a>
          </div>

          <Button
            variant="outline"
            size="icon"
            className="rounded-full"
            onClick={scrollToTop}
          >
            <ArrowUp className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </footer>
  );
};
