import { motion } from 'framer-motion';
import { Heart, Bell, Calendar, AlertTriangle, Users, Clock, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useFollowing } from '@/hooks/useFollowing';
import { societies, getStatusBadge, getStatusText, categoryLabels, getCategoryColor } from '@/data/societies';
import { SocietyCard } from './SocietyCard';
import { useState } from 'react';
import { SocietyModal } from './SocietyModal';
import { Society } from '@/data/societies';

export const FollowingSection = () => {
  const { following, toggleFollow } = useFollowing();
  const [selectedSociety, setSelectedSociety] = useState<Society | null>(null);

  const followedSocieties = societies.filter(s => following.includes(s.id));
  
  const openRegistrations = followedSocieties.filter(s => s.registrationStatus === 'open');
  const upcomingRegistrations = followedSocieties.filter(s => s.registrationStatus === 'soon');
  const upcomingFests = followedSocieties.filter(s => s.fest);

  if (following.length === 0) {
    return (
      <section id="following" className="py-20 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <div className="max-w-md mx-auto glass-card p-12 rounded-3xl">
              <div className="w-20 h-20 rounded-full bg-primary/10 mx-auto mb-6 flex items-center justify-center">
                <Heart className="w-10 h-10 text-primary" />
              </div>
              <h2 className="font-display text-2xl font-bold mb-4">
                Start Following Societies
              </h2>
              <p className="text-muted-foreground mb-6">
                Follow your favorite societies to get personalized updates, registration alerts, and event notifications.
              </p>
              <Button 
                className="bg-gradient-to-r from-primary to-accent text-primary-foreground"
                onClick={() => {
                  document.getElementById('societies')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Explore Societies
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="following" className="py-20 relative">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            <span className="gradient-text">My</span> Dashboard
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Your personalized feed with updates from {following.length} followed societies.
          </p>
        </motion.div>

        {/* Quick Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
        >
          <div className="glass-card p-4 rounded-xl text-center">
            <Heart className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{following.length}</p>
            <p className="text-sm text-muted-foreground">Following</p>
          </div>
          <div className="glass-card p-4 rounded-xl text-center">
            <div className="w-6 h-6 rounded-full bg-emerald-500/20 mx-auto mb-2 flex items-center justify-center">
              <span className="w-3 h-3 rounded-full bg-emerald-500" />
            </div>
            <p className="text-2xl font-bold text-foreground">{openRegistrations.length}</p>
            <p className="text-sm text-muted-foreground">Open Now</p>
          </div>
          <div className="glass-card p-4 rounded-xl text-center">
            <Clock className="w-6 h-6 text-amber-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{upcomingRegistrations.length}</p>
            <p className="text-sm text-muted-foreground">Opening Soon</p>
          </div>
          <div className="glass-card p-4 rounded-xl text-center">
            <Calendar className="w-6 h-6 text-accent mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{upcomingFests.length}</p>
            <p className="text-sm text-muted-foreground">Upcoming Fests</p>
          </div>
        </motion.div>

        {/* Alerts Section */}
        {openRegistrations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mb-8"
          >
            <div className="glass-card p-6 rounded-2xl border-l-4 border-emerald-500">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                  <Bell className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-2">
                    Registrations Open! Don't Miss Out
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {openRegistrations.map(society => (
                      <span
                        key={society.id}
                        className="px-3 py-1.5 rounded-full text-sm bg-emerald-500/10 text-emerald-400 cursor-pointer hover:bg-emerald-500/20 transition-colors"
                        onClick={() => setSelectedSociety(society)}
                      >
                        {society.name}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Following Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="font-display text-xl font-bold mb-6 flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Following ({following.length})
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {followedSocieties.map((society, index) => (
              <SocietyCard
                key={society.id}
                society={society}
                index={index}
                onClick={() => setSelectedSociety(society)}
              />
            ))}
          </div>
        </motion.div>
      </div>

      <SocietyModal
        society={selectedSociety}
        isOpen={!!selectedSociety}
        onClose={() => setSelectedSociety(null)}
      />
    </section>
  );
};
