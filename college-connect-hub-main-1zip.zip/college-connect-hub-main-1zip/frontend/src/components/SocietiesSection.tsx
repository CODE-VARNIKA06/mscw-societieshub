import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, X, Grid, LayoutGrid } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { SocietyCard } from './SocietyCard';
import { SocietyModal } from './SocietyModal';
import { societies, Society, SocietyCategory, RegistrationStatus, categoryLabels } from '@/data/societies';

export const SocietiesSection = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<SocietyCategory | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<RegistrationStatus | 'all'>('all');
  const [selectedSociety, setSelectedSociety] = useState<Society | null>(null);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const categories: (SocietyCategory | 'all')[] = ['all', 'tech', 'cultural', 'sports', 'arts', 'media', 'academic'];
  const statuses: (RegistrationStatus | 'all')[] = ['all', 'open', 'soon', 'closed'];

  const filteredSocieties = useMemo(() => {
    return societies.filter(society => {
      const matchesSearch = society.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           society.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           society.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || society.category === selectedCategory;
      const matchesStatus = selectedStatus === 'all' || society.registrationStatus === selectedStatus;
      
      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [searchQuery, selectedCategory, selectedStatus]);

  const activeFiltersCount = (selectedCategory !== 'all' ? 1 : 0) + (selectedStatus !== 'all' ? 1 : 0);

  return (
    <section id="societies" className="py-20 relative">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            <span className="gradient-text">Discover</span> Societies
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore {societies.length}+ societies across various departments. Find your passion and join your community.
          </p>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search societies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 bg-card/50 border-border/50 rounded-xl focus:ring-2 focus:ring-primary/30"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Filter Toggle */}
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                className={`gap-2 ${isFilterOpen ? 'bg-primary/10 border-primary/30' : ''}`}
                onClick={() => setIsFilterOpen(!isFilterOpen)}
              >
                <Filter className="w-4 h-4" />
                Filters
                {activeFiltersCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                    {activeFiltersCount}
                  </span>
                )}
              </Button>
            </div>
          </div>

          {/* Filter Panel */}
          <AnimatePresence>
            {isFilterOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="glass-card p-6 mt-4 rounded-2xl">
                  <div className="grid md:grid-cols-2 gap-6">
                    {/* Category Filter */}
                    <div>
                      <label className="text-sm font-medium text-muted-foreground mb-3 block">
                        Category
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {categories.map((cat) => (
                          <Button
                            key={cat}
                            size="sm"
                            variant={selectedCategory === cat ? 'default' : 'outline'}
                            className={`rounded-full ${
                              selectedCategory === cat 
                                ? 'bg-primary text-primary-foreground' 
                                : 'border-border/50 hover:bg-secondary'
                            }`}
                            onClick={() => setSelectedCategory(cat)}
                          >
                            {cat === 'all' ? 'All' : categoryLabels[cat]}
                          </Button>
                        ))}
                      </div>
                    </div>

                    {/* Status Filter */}
                    <div>
                      <label className="text-sm font-medium text-muted-foreground mb-3 block">
                        Registration Status
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {statuses.map((status) => (
                          <Button
                            key={status}
                            size="sm"
                            variant={selectedStatus === status ? 'default' : 'outline'}
                            className={`rounded-full ${
                              selectedStatus === status 
                                ? 'bg-primary text-primary-foreground' 
                                : 'border-border/50 hover:bg-secondary'
                            }`}
                            onClick={() => setSelectedStatus(status)}
                          >
                            {status === 'all' ? 'All' : status === 'soon' ? 'Opening Soon' : status.charAt(0).toUpperCase() + status.slice(1)}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Clear Filters */}
                  {activeFiltersCount > 0 && (
                    <div className="mt-4 pt-4 border-t border-border/50">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-muted-foreground"
                        onClick={() => {
                          setSelectedCategory('all');
                          setSelectedStatus('all');
                        }}
                      >
                        <X className="w-4 h-4 mr-2" />
                        Clear all filters
                      </Button>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Results Count */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-muted-foreground">
            Showing <span className="font-semibold text-foreground">{filteredSocieties.length}</span> societies
          </p>
        </div>

        {/* Society Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredSocieties.map((society, index) => (
              <SocietyCard
                key={society.id}
                society={society}
                index={index}
                onClick={() => setSelectedSociety(society)}
              />
            ))}
          </AnimatePresence>
        </div>

        {/* Empty State */}
        {filteredSocieties.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-display text-xl font-bold mb-2">No societies found</h3>
            <p className="text-muted-foreground mb-4">
              Try adjusting your search or filter criteria
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedStatus('all');
              }}
            >
              Clear filters
            </Button>
          </motion.div>
        )}
      </div>

      {/* Society Modal */}
      <SocietyModal
        society={selectedSociety}
        isOpen={!!selectedSociety}
        onClose={() => setSelectedSociety(null)}
      />
    </section>
  );
};
