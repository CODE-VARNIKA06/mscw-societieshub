import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, BackendSociety } from '@/services/api';
import { societies as staticSocieties, Society } from '@/data/societies';

export const useSocieties = () => {
  const queryClient = useQueryClient();

  const { data: backendSocieties, isLoading, error } = useQuery({
    queryKey: ['societies'],
    queryFn: api.getSocieties,
    staleTime: 1000 * 60 * 5,
  });

  const mergedSocieties = staticSocieties.map(society => {
    const backendMatch = backendSocieties?.find(bs => bs.name.toLowerCase() === society.name.toLowerCase());
    if (backendMatch) {
      return {
        ...society,
        id: backendMatch.id,
        description: backendMatch.description || society.description,
      };
    }
    return society;
  });

  const additionalBackendSocieties: Society[] = (backendSocieties || [])
    .filter(bs => !staticSocieties.some(ss => ss.name.toLowerCase() === bs.name.toLowerCase()))
    .map(bs => ({
      id: bs.id,
      name: bs.name,
      department: 'General',
      category: 'academic' as const,
      description: bs.description,
      memberCount: 0,
      registrationStatus: 'open' as const,
      gallery: [],
      contact: {
        president: 'TBA',
        prLead: 'TBA',
      },
      colorAccent: '217 91% 60%',
    }));

  const allSocieties = [...mergedSocieties, ...additionalBackendSocieties];

  const addSocietyMutation = useMutation({
    mutationFn: ({ name, description }: { name: string; description: string }) =>
      api.addSociety(name, description),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['societies'] });
    },
  });

  return {
    societies: allSocieties,
    isLoading,
    error,
    addSociety: addSocietyMutation.mutate,
    isAddingSociety: addSocietyMutation.isPending,
  };
};
