# College Connect Hub

## Overview
Full-stack college society management system with a React frontend and Flask backend, using Firebase for authentication and Firestore for database.

## Project Structure
```
/
├── main.py                    # Flask API server (port 3000)
├── firebase_key.json          # Firebase credentials (gitignored)
├── frontend/                  # React frontend (port 5000)
│   ├── src/
│   │   ├── services/api.ts    # Backend API integration
│   │   ├── hooks/             # React hooks for data fetching
│   │   ├── components/        # UI components
│   │   └── data/societies.ts  # Static society data
│   └── dist/                  # Production build output
```

## Running the App
- **Frontend**: Runs on port 5000 (visible in webview)
- **Backend**: Runs on port 3000 (internal API)

## API Endpoints (Backend)
- `GET /` - Health check
- `POST /register` - Register new user (email, password, role)
- `POST /add_society` - Add new society (name, description)
- `GET /societies` - List all societies
- `POST /add_event` - Add new event (title, society, date)
- `GET /events` - List all events
- `POST /follow` - Follow a society (user_id, society)

## Frontend Features
- Browse and search societies
- Filter by category and registration status
- Follow/unfollow societies (syncs with backend)
- View society details in modal
- Responsive dark theme design

## Build Commands
- `cd frontend && npm run build` - Build for production
- `cd frontend && npm run dev` - Development server

## Recent Changes
- 2026-01-31: Built frontend for production
- 2026-01-30: Connected frontend to Flask backend API
- 2026-01-30: Initial setup - Flask backend with Firebase integration
